# This is a first-level heading

## This is a second-level heading

### This is a third-level heading

This is a paragraph.

This is a second paragraph.

- Bullet-list item 1
- Bullet-list item 2
- Bullet-list item 3
  - Sub-bullet-list item 1

1. Numbered list item 1
1. Numbered list item 2
1. Numbered list item 3
  1 Sub-numbered-list item 1

Here is some *italicized* and **bold** text.
